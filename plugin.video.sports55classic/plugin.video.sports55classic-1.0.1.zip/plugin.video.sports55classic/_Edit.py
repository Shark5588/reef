import xbmcaddon
import base64

Decode = base64.decodestring
MainBase = base64.b64decode ('aHR0cHM6Ly9iaXQubHkvMlExRVNMMg==')
addon = xbmcaddon.Addon('plugin.video.sports55classic')